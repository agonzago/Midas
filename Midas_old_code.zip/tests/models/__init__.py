# tests/models/__init__.py
# This file makes Python treat the 'models' directory under 'tests' as a package.
pass
