# tests/data_handling/__init__.py
# This file makes Python treat the 'data_handling' directory under 'tests' as a package.
pass
