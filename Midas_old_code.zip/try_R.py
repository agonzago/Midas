rm(list=ls())
setwd("/Volumes/TOSHIBA EXT/main_work/projects/")







